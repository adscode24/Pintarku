import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { playSound, speakIndonesian } from '../utils/audio';
import confetti from 'canvas-confetti';
import {
  Maximize2,
  Minimize2,
  X,
  Clock,
  Sparkles,
  Trophy,
  RotateCcw,
  Zap,
  CheckCircle2,
  AlertTriangle,
  PackageCheck,
  ChevronRight,
  Backpack,
  Compass,
  ArrowUp
} from 'lucide-react';

interface SchoolItems3DGameProps {
  onClose: () => void;
  onEarnStar?: () => void;
}

export type Character3DId = 'budi' | 'siti' | 'robo' | 'kancil';

interface Character3DOption {
  id: Character3DId;
  name: string;
  role: string;
  emoji: string;
  shirtColor: number;
  pantsColor: number;
  hairColor: number;
  accessory: string;
  description: string;
}

const CHARACTERS_3D: Character3DOption[] = [
  {
    id: 'budi',
    name: 'Budi Juara',
    role: 'Siswa Pintar',
    emoji: '👦',
    shirtColor: 0xffffff,
    pantsColor: 0xcc0000,
    hairColor: 0x1f2937,
    accessory: 'Topi Sekolah Merah Putih',
    description: 'Rajin, disiplin, dan gesit mencari perlengkapan kelas.',
  },
  {
    id: 'siti',
    name: 'Siti Cerdas',
    role: 'Siswi Ceria',
    emoji: '👧',
    shirtColor: 0xffffff,
    pantsColor: 0xcc0000,
    hairColor: 0x312e81,
    accessory: 'Pita Rambut Berkilau',
    description: 'Teliti membedakan mana barang sekolah dan barang asing.',
  },
  {
    id: 'robo',
    name: 'Robo-KID',
    role: 'Robot Sahabat',
    emoji: '🤖',
    shirtColor: 0x0284c7,
    pantsColor: 0x0f172a,
    hairColor: 0x38bdf8,
    accessory: 'Antena Sensor Canggih',
    description: 'Robot sekolah berkecepatan tinggi dengan radar akurat.',
  },
  {
    id: 'kancil',
    name: 'Kancil Cerdik',
    role: 'Maskot Cilik',
    emoji: '🦊',
    shirtColor: 0xf97316,
    pantsColor: 0x7c2d12,
    hairColor: 0xfbbf24,
    accessory: 'Syal Petualang',
    description: 'Lincah berkeliling seluruh taman sekolah.',
  },
];

interface WorldItem {
  id: string;
  name: string;
  isSchoolItem: boolean;
  mesh: THREE.Group;
  x: number;
  z: number;
  collected: boolean;
  baseY: number;
  points: number;
  emoji: string;
}

interface HeldItem {
  id: string;
  name: string;
  isSchoolItem: boolean;
  emoji: string;
}

export default function SchoolItems3DGame({ onClose, onEarnStar }: SchoolItems3DGameProps) {
  // Game state
  const [selectedChar, setSelectedChar] = useState<Character3DId>('budi');
  const [gameStage, setGameStage] = useState<'character_select' | 'playing' | 'gameover'>('character_select');
  const [timeLeft, setTimeLeft] = useState<number>(60);
  const [score, setScore] = useState<number>(0);
  const [schoolItemsCount, setSchoolItemsCount] = useState<number>(0);
  const [wrongItemsCount, setWrongItemsCount] = useState<number>(0);
  const [heldItems, setHeldItems] = useState<HeldItem[]>([]);
  const [toastMessage, setToastMessage] = useState<{ text: string; isError?: boolean } | null>(null);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(true);
  const [sprintActive, setSprintActive] = useState<boolean>(false);

  // Canvas & Three.js refs
  const mountRef = useRef<HTMLDivElement | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const characterMeshRef = useRef<THREE.Group | null>(null);
  const leftLegRef = useRef<THREE.Mesh | null>(null);
  const rightLegRef = useRef<THREE.Mesh | null>(null);
  const leftArmRef = useRef<THREE.Mesh | null>(null);
  const rightArmRef = useRef<THREE.Mesh | null>(null);
  const animFrameIdRef = useRef<number | null>(null);
  const worldItemsRef = useRef<WorldItem[]>([]);
  const collectionZoneMeshRef = useRef<THREE.Mesh | null>(null);
  const collectionRingsRef = useRef<THREE.Group | null>(null);

  // Movement physics state
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const joystickRef = useRef<{ x: number; y: number; active: boolean }>({ x: 0, y: 0, active: false });
  const playerPosRef = useRef<{ x: number; z: number; rotation: number; speed: number }>({
    x: 0,
    z: 14,
    rotation: Math.PI,
    speed: 0,
  });

  // Collection Zone position in world
  const COLLECTION_ZONE = { x: 0, z: 0, radius: 4.5 };

  // Toast notification helper
  const showToast = useCallback((text: string, isError = false) => {
    setToastMessage({ text, isError });
    setTimeout(() => {
      setToastMessage((prev) => (prev?.text === text ? null : prev));
    }, 2400);
  }, []);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.code] = true;
      if (e.code === 'KeyE' || e.code === 'Space') {
        attemptPickup();
      }
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
        setSprintActive(true);
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
        setSprintActive(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [heldItems, gameStage]);

  // Fullscreen toggle
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.().catch(() => {});
      setIsFullscreen(false);
    }
  };

  // Start 3D Game
  const handleStartGame = () => {
    setGameStage('playing');
    setTimeLeft(60);
    setScore(0);
    setSchoolItemsCount(0);
    setWrongItemsCount(0);
    setHeldItems([]);
    playerPosRef.current = { x: 0, z: 14, rotation: Math.PI, speed: 0 };
    playSound('pop');
    speakIndonesian('Ayo kumpulkan barang-barang sekolah dan bawa ke area pengumpulan!');
  };

  // 60-second Timer Loop
  useEffect(() => {
    if (gameStage !== 'playing') return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          finishGame();
          return 0;
        }
        if (prev === 11) {
          playSound('star');
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [gameStage]);

  // Finish Game & Show Results
  const finishGame = useCallback(() => {
    setGameStage('gameover');
    playSound('victory');
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.5 },
    });
    if (onEarnStar) {
      onEarnStar();
    }
    speakIndonesian('Waktu habis! Kerja bagus mengumpulkan perlengkapan sekolah!');
  }, [onEarnStar]);

  // Pickup Attempt (Action Button / Proximity)
  const attemptPickup = useCallback(() => {
    if (gameStage !== 'playing') return;

    const player = playerPosRef.current;
    const items = worldItemsRef.current;

    // Check if near any uncollected item
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.collected) continue;

      const dist = Math.hypot(player.x - item.x, player.z - item.z);
      if (dist < 2.8) {
        // Collect this item into backpack
        item.collected = true;
        item.mesh.visible = false;

        const newHeld: HeldItem = {
          id: item.id,
          name: item.name,
          isSchoolItem: item.isSchoolItem,
          emoji: item.emoji,
        };

        setHeldItems((prev) => [...prev, newHeld]);

        if (item.isSchoolItem) {
          playSound('apple');
          showToast(`🎒 Mengambil: ${item.name} (${item.emoji})`, false);
        } else {
          playSound('wrong');
          showToast(`⚠️ Mengambil: ${item.name} (${item.emoji}) - Hati-hati! Ini bukan barang sekolah!`, true);
        }
        return;
      }
    }
  }, [gameStage, showToast]);

  // Three.js Scene Setup & Render Loop
  useEffect(() => {
    if (gameStage !== 'playing') return;
    const container = mountRef.current;
    if (!container) return;

    // 1. Scene & Camera
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x7dd3fc); // Sunny sky blue
    scene.fog = new THREE.FogExp2(0x7dd3fc, 0.015);

    const camera = new THREE.PerspectiveCamera(50, container.clientWidth / container.clientHeight, 0.1, 100);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    rendererRef.current = renderer;
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 2. Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xfff7ed, 1.1);
    dirLight.position.set(20, 35, 20);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 80;
    const d = 30;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    scene.add(dirLight);

    // 3. Environment: Ground, Courtyard, School Building & Details
    const groundGeo = new THREE.PlaneGeometry(80, 80);
    const groundMat = new THREE.MeshLambertMaterial({ color: 0x86efac });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Grid path on school courtyard
    const pathGeo = new THREE.PlaneGeometry(14, 50);
    const pathMat = new THREE.MeshLambertMaterial({ color: 0xfef3c7 });
    const path = new THREE.Mesh(pathGeo, pathMat);
    path.rotation.x = -Math.PI / 2;
    path.position.y = 0.02;
    path.receiveShadow = true;
    scene.add(path);

    // School Main Building (Background)
    const schoolGroup = new THREE.Group();
    const schoolMat = new THREE.MeshLambertMaterial({ color: 0xffedd5 });
    const schoolWall = new THREE.Mesh(new THREE.BoxGeometry(28, 10, 8), schoolMat);
    schoolWall.position.set(0, 5, -22);
    schoolWall.castShadow = true;
    schoolWall.receiveShadow = true;
    schoolGroup.add(schoolWall);

    // School Roof
    const roofMat = new THREE.MeshLambertMaterial({ color: 0xd97706 });
    const roof = new THREE.Mesh(new THREE.ConeGeometry(20, 4, 4), roofMat);
    roof.position.set(0, 12, -22);
    roof.rotation.y = Math.PI / 4;
    roof.scale.set(1.1, 1, 0.6);
    schoolGroup.add(roof);

    // School Door & Windows
    const doorMat = new THREE.MeshLambertMaterial({ color: 0x92400e });
    const door = new THREE.Mesh(new THREE.BoxGeometry(4, 5, 0.2), doorMat);
    door.position.set(0, 2.5, -17.9);
    schoolGroup.add(door);

    // Windows
    const winMat = new THREE.MeshLambertMaterial({ color: 0x38bdf8 });
    [-8, -4, 4, 8].forEach((wx) => {
      const win = new THREE.Mesh(new THREE.BoxGeometry(2.5, 2.5, 0.2), winMat);
      win.position.set(wx, 6, -17.9);
      schoolGroup.add(win);
    });
    scene.add(schoolGroup);

    // Flagpole with Indonesian Flag
    const poleMat = new THREE.MeshLambertMaterial({ color: 0xe2e8f0 });
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 10, 16), poleMat);
    pole.position.set(0, 5, -10);
    pole.castShadow = true;
    scene.add(pole);

    // Flag (Red & White)
    const flagGroup = new THREE.Group();
    const flagRed = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.6), new THREE.MeshBasicMaterial({ color: 0xef4444, side: THREE.DoubleSide }));
    flagRed.position.set(0.9, 8.8, -10);
    const flagWhite = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.6), new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide }));
    flagWhite.position.set(0.9, 8.2, -10);
    flagGroup.add(flagRed, flagWhite);
    scene.add(flagGroup);

    // Trees & Bushes
    const createTree = (x: number, z: number) => {
      const tree = new THREE.Group();
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.4, 3, 8), new THREE.MeshLambertMaterial({ color: 0x78350f }));
      trunk.position.y = 1.5;
      trunk.castShadow = true;
      const leaves = new THREE.Mesh(new THREE.DodecahedronGeometry(1.8, 1), new THREE.MeshLambertMaterial({ color: 0x15803d }));
      leaves.position.y = 3.6;
      leaves.castShadow = true;
      tree.add(trunk, leaves);
      tree.position.set(x, 0, z);
      scene.add(tree);
    };

    [
      [-16, -10], [16, -10],
      [-18, 5], [18, 5],
      [-16, 20], [16, 20],
      [-10, 26], [10, 26],
      [-22, -18], [22, -18],
    ].forEach(([tx, tz]) => createTree(tx, tz));

    // 4. COLLECTION ZONE (Area Pengumpulan Emas)
    const zoneGroup = new THREE.Group();
    const zoneFloorGeo = new THREE.CylinderGeometry(COLLECTION_ZONE.radius, COLLECTION_ZONE.radius, 0.1, 32);
    const zoneFloorMat = new THREE.MeshLambertMaterial({ color: 0xfef08a, transparent: true, opacity: 0.85 });
    const zoneFloor = new THREE.Mesh(zoneFloorGeo, zoneFloorMat);
    zoneFloor.position.set(COLLECTION_ZONE.x, 0.05, COLLECTION_ZONE.z);
    zoneFloor.receiveShadow = true;
    zoneGroup.add(zoneFloor);
    collectionZoneMeshRef.current = zoneFloor;

    // Glowing Animated Rings
    const ringsGroup = new THREE.Group();
    const ringGeo = new THREE.RingGeometry(COLLECTION_ZONE.radius - 0.4, COLLECTION_ZONE.radius, 32);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b, side: THREE.DoubleSide });
    const ring1 = new THREE.Mesh(ringGeo, ringMat);
    ring1.rotation.x = -Math.PI / 2;
    ring1.position.y = 0.08;
    ringsGroup.add(ring1);
    zoneGroup.add(ringsGroup);
    collectionRingsRef.current = ringsGroup;

    // Teacher's Desk / Collection Box inside zone
    const deskMat = new THREE.MeshLambertMaterial({ color: 0xb45309 });
    const desk = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.2, 1.2), deskMat);
    desk.position.set(COLLECTION_ZONE.x, 0.6, COLLECTION_ZONE.z - 0.5);
    desk.castShadow = true;
    zoneGroup.add(desk);

    // Signpost
    const signMat = new THREE.MeshLambertMaterial({ color: 0xd97706 });
    const signPole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2.2), signMat);
    signPole.position.set(COLLECTION_ZONE.x, 1.1, COLLECTION_ZONE.z + 1.2);
    const signBoard = new THREE.Mesh(new THREE.BoxGeometry(2, 0.8, 0.1), new THREE.MeshLambertMaterial({ color: 0xef4444 }));
    signBoard.position.set(COLLECTION_ZONE.x, 2, COLLECTION_ZONE.z + 1.2);
    zoneGroup.add(signPole, signBoard);

    scene.add(zoneGroup);

    // 5. Create 3D Character
    const charData = CHARACTERS_3D.find((c) => c.id === selectedChar) || CHARACTERS_3D[0];
    const characterGroup = new THREE.Group();

    // Body
    const bodyGeo = new THREE.BoxGeometry(1, 1.2, 0.6);
    const bodyMat = new THREE.MeshLambertMaterial({ color: charData.shirtColor });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.y = 1.3;
    body.castShadow = true;
    characterGroup.add(body);

    // Head
    const headGeo = new THREE.SphereGeometry(0.48, 16, 16);
    const headMat = new THREE.MeshLambertMaterial({ color: 0xfed7aa }); // Skin tone
    const head = new THREE.Mesh(headGeo, headMat);
    head.position.y = 2.25;
    head.castShadow = true;
    characterGroup.add(head);

    // Hair / Hat / Accessory
    const hairGeo = new THREE.ConeGeometry(0.55, 0.4, 16);
    const hairMat = new THREE.MeshLambertMaterial({ color: charData.hairColor });
    const hair = new THREE.Mesh(hairGeo, hairMat);
    hair.position.y = 2.6;
    characterGroup.add(hair);

    // Backpack
    const backpackGeo = new THREE.BoxGeometry(0.7, 0.8, 0.35);
    const backpackMat = new THREE.MeshLambertMaterial({ color: 0x2563eb });
    const backpack = new THREE.Mesh(backpackGeo, backpackMat);
    backpack.position.set(0, 1.3, -0.45);
    backpack.castShadow = true;
    characterGroup.add(backpack);

    // Legs
    const legGeo = new THREE.BoxGeometry(0.32, 0.8, 0.35);
    const legMat = new THREE.MeshLambertMaterial({ color: charData.pantsColor });
    const leftLeg = new THREE.Mesh(legGeo, legMat);
    leftLeg.position.set(-0.25, 0.4, 0);
    leftLeg.castShadow = true;
    const rightLeg = new THREE.Mesh(legGeo, legMat);
    rightLeg.position.set(0.25, 0.4, 0);
    rightLeg.castShadow = true;
    characterGroup.add(leftLeg, rightLeg);
    leftLegRef.current = leftLeg;
    rightLegRef.current = rightLeg;

    // Arms
    const armGeo = new THREE.BoxGeometry(0.25, 0.75, 0.25);
    const armMat = new THREE.MeshLambertMaterial({ color: charData.shirtColor });
    const leftArm = new THREE.Mesh(armGeo, armMat);
    leftArm.position.set(-0.65, 1.25, 0);
    leftArm.castShadow = true;
    const rightArm = new THREE.Mesh(armGeo, armMat);
    rightArm.position.set(0.65, 1.25, 0);
    rightArm.castShadow = true;
    characterGroup.add(leftArm, rightArm);
    leftArmRef.current = leftArm;
    rightArmRef.current = rightArm;

    characterGroup.position.set(playerPosRef.current.x, 0, playerPosRef.current.z);
    scene.add(characterGroup);
    characterMeshRef.current = characterGroup;

    // 6. SPAWN ITEMS ACROSS THE 3D WORLD
    // School items (+10) and Non-school items (-5)
    const itemsData: { name: string; isSchool: boolean; emoji: string; color: number; type: string }[] = [
      // School items
      { name: 'Buku Pelajaran', isSchool: true, emoji: '📚', color: 0x3b82f6, type: 'book' },
      { name: 'Pensil Warna', isSchool: true, emoji: '✏️', color: 0xf59e0b, type: 'pencil' },
      { name: 'Tas Ransel', isSchool: true, emoji: '🎒', color: 0x10b981, type: 'bag' },
      { name: 'Penggaris Segitiga', isSchool: true, emoji: '📐', color: 0xec4899, type: 'ruler' },
      { name: 'Kotak Krayon', isSchool: true, emoji: '🖍️', color: 0x8b5cf6, type: 'crayon' },
      { name: 'Botol Minum', isSchool: true, emoji: '🧴', color: 0x06b6d4, type: 'bottle' },
      { name: 'Buku Catatan', isSchool: true, emoji: '📓', color: 0x6366f1, type: 'book' },
      { name: 'Kamus Cilik', isSchool: true, emoji: '📕', color: 0xef4444, type: 'book' },

      // Non-school items (Sampah / Mainan / Makanan - Pengurang Nilai)
      { name: 'Stik Game PS', isSchool: false, emoji: '🎮', color: 0x334155, type: 'gamepad' },
      { name: 'Burger Cepat Saji', isSchool: false, emoji: '🍔', color: 0xd97706, type: 'burger' },
      { name: 'Kaos Kaki Kotor', isSchool: false, emoji: '🧦', color: 0x64748b, type: 'sock' },
      { name: 'Skateboard Rusak', isSchool: false, emoji: '🛹', color: 0x475569, type: 'skateboard' },
      { name: 'Tulang Gigit Anjing', isSchool: false, emoji: '🦴', color: 0xf1f5f9, type: 'bone' },
      { name: 'Remote TV', isSchool: false, emoji: '📺', color: 0x1e293b, type: 'remote' },
    ];

    const worldItems: WorldItem[] = [];

    // Helper to generate non-overlapping random positions around the world
    const spawnPositions: [number, number][] = [
      // Left wing
      [-10, 8], [-14, 14], [-7, 18], [-12, -4], [-8, -12], [-14, 2],
      // Right wing
      [10, 8], [14, 14], [7, 18], [12, -4], [8, -12], [14, 2],
      // Front and center paths
      [-4, 22], [4, 22], [-5, 12], [6, 12],
    ];

    itemsData.forEach((itemInfo, index) => {
      const pos = spawnPositions[index % spawnPositions.length];
      // Jitter pos slightly
      const x = pos[0] + (Math.random() - 0.5) * 2.5;
      const z = pos[1] + (Math.random() - 0.5) * 2.5;

      const itemGroup = new THREE.Group();

      // Glowing aura pedestal
      const auraMat = new THREE.MeshBasicMaterial({
        color: itemInfo.isSchool ? 0x60a5fa : 0xf87171,
        transparent: true,
        opacity: 0.45,
      });
      const aura = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.7, 0.05, 16), auraMat);
      aura.position.y = 0.05;
      itemGroup.add(aura);

      // Item 3D geometry
      let meshObj: THREE.Mesh;
      if (itemInfo.type === 'book') {
        meshObj = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.9, 0.2), new THREE.MeshLambertMaterial({ color: itemInfo.color }));
      } else if (itemInfo.type === 'pencil' || itemInfo.type === 'crayon') {
        meshObj = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 1.1, 12), new THREE.MeshLambertMaterial({ color: itemInfo.color }));
      } else if (itemInfo.type === 'bag') {
        meshObj = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.9, 0.5), new THREE.MeshLambertMaterial({ color: itemInfo.color }));
      } else if (itemInfo.type === 'ruler') {
        meshObj = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.2, 0.05), new THREE.MeshLambertMaterial({ color: itemInfo.color }));
      } else if (itemInfo.type === 'burger') {
        meshObj = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.4, 16), new THREE.MeshLambertMaterial({ color: itemInfo.color }));
      } else {
        meshObj = new THREE.Mesh(new THREE.DodecahedronGeometry(0.45), new THREE.MeshLambertMaterial({ color: itemInfo.color }));
      }

      meshObj.position.y = 1.1;
      meshObj.castShadow = true;
      itemGroup.add(meshObj);

      itemGroup.position.set(x, 0, z);
      scene.add(itemGroup);

      worldItems.push({
        id: `item-${index}`,
        name: itemInfo.name,
        isSchoolItem: itemInfo.isSchool,
        mesh: itemGroup,
        x,
        z,
        collected: false,
        baseY: 1.1,
        points: itemInfo.isSchool ? 10 : -5,
        emoji: itemInfo.emoji,
      });
    });

    worldItemsRef.current = worldItems;

    // 7. Render Animation Loop
    let clock = new THREE.Clock();

    const animate = () => {
      const delta = clock.getDelta();
      const elapsedTime = clock.getElapsedTime();

      // Read Input & Move Player
      let moveX = 0;
      let moveZ = 0;

      // Keyboard
      if (keysRef.current['KeyW'] || keysRef.current['ArrowUp']) moveZ -= 1;
      if (keysRef.current['KeyS'] || keysRef.current['ArrowDown']) moveZ += 1;
      if (keysRef.current['KeyA'] || keysRef.current['ArrowLeft']) moveX -= 1;
      if (keysRef.current['KeyD'] || keysRef.current['ArrowRight']) moveX += 1;

      // Virtual Joystick Input
      if (joystickRef.current.active) {
        moveX = joystickRef.current.x;
        moveZ = joystickRef.current.y;
      }

      const inputLength = Math.hypot(moveX, moveZ);
      const isMoving = inputLength > 0.1;
      const speedMultiplier = sprintActive ? 1.6 : 1.0;
      const baseSpeed = 7.5;

      const player = playerPosRef.current;

      if (isMoving) {
        const normX = moveX / (inputLength || 1);
        const normZ = moveZ / (inputLength || 1);

        player.x += normX * baseSpeed * speedMultiplier * delta;
        player.z += normZ * baseSpeed * speedMultiplier * delta;

        // World boundary limits
        player.x = Math.max(-25, Math.min(25, player.x));
        player.z = Math.max(-18, Math.min(26, player.z));

        // Smooth rotation towards movement direction
        const targetRotation = Math.atan2(normX, normZ);
        player.rotation = targetRotation;

        // Limb swinging animation
        const swingSpeed = 12 * speedMultiplier;
        const swingAngle = Math.sin(elapsedTime * swingSpeed) * 0.55;
        if (leftLegRef.current && rightLegRef.current) {
          leftLegRef.current.rotation.x = swingAngle;
          rightLegRef.current.rotation.x = -swingAngle;
        }
        if (leftArmRef.current && rightArmRef.current) {
          leftArmRef.current.rotation.x = -swingAngle * 0.8;
          rightArmRef.current.rotation.x = swingAngle * 0.8;
        }
      } else {
        // Idle limb reset
        if (leftLegRef.current && rightLegRef.current) {
          leftLegRef.current.rotation.x = 0;
          rightLegRef.current.rotation.x = 0;
        }
        if (leftArmRef.current && rightArmRef.current) {
          leftArmRef.current.rotation.x = 0;
          rightArmRef.current.rotation.x = 0;
        }
      }

      // Update Character Mesh Transform
      if (characterMeshRef.current) {
        characterMeshRef.current.position.set(player.x, 0, player.z);
        characterMeshRef.current.rotation.y = player.rotation;
      }

      // Follow Camera with smooth dampening
      const targetCamX = player.x;
      const targetCamY = 7.5;
      const targetCamZ = player.z + 10;
      camera.position.x += (targetCamX - camera.position.x) * 0.1;
      camera.position.y += (targetCamY - camera.position.y) * 0.1;
      camera.position.z += (targetCamZ - camera.position.z) * 0.1;
      camera.lookAt(player.x, 1.5, player.z);

      // Rotate & Bob World Collectibles
      worldItemsRef.current.forEach((item) => {
        if (!item.collected && item.mesh) {
          item.mesh.rotation.y += 1.8 * delta;
          const childMesh = item.mesh.children[1];
          if (childMesh) {
            childMesh.position.y = item.baseY + Math.sin(elapsedTime * 3 + item.x) * 0.18;
          }
        }
      });

      // Animate Collection Zone Ring
      if (collectionRingsRef.current) {
        collectionRingsRef.current.rotation.y += 0.8 * delta;
      }

      // Proximity Auto-Pickup Check (jika sangat dekat)
      worldItemsRef.current.forEach((item) => {
        if (!item.collected) {
          const dist = Math.hypot(player.x - item.x, player.z - item.z);
          if (dist < 1.6) {
            attemptPickup();
          }
        }
      });

      renderer.render(scene, camera);
      animFrameIdRef.current = requestAnimationFrame(animate);
    };

    animFrameIdRef.current = requestAnimationFrame(animate);

    // Resize Handler
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
      renderer.dispose();
      scene.clear();
    };
  }, [gameStage, selectedChar, attemptPickup, sprintActive]);

  // Check if player is currently inside the Collection Zone
  const isInsideCollectionZone = () => {
    const player = playerPosRef.current;
    const dist = Math.hypot(player.x - COLLECTION_ZONE.x, player.z - COLLECTION_ZONE.z);
    return dist <= COLLECTION_ZONE.radius;
  };

  // Deposit items from backpack into Collection Zone
  const handleDepositItems = () => {
    if (heldItems.length === 0) {
      showToast('Tas ranselmu kosong! Cari barang perlengkapan sekolah terlebih dahulu.', true);
      return;
    }

    if (!isInsideCollectionZone()) {
      showToast('Ayo kembali ke ZONA PENGUMPULAN (lingkaran emas) untuk menyetor barang!', true);
      return;
    }

    let deltaScore = 0;
    let addedSchool = 0;
    let addedWrong = 0;

    heldItems.forEach((item) => {
      if (item.isSchoolItem) {
        deltaScore += 10;
        addedSchool += 1;
      } else {
        deltaScore -= 5;
        addedWrong += 1;
      }
    });

    setScore((prev) => Math.max(0, prev + deltaScore));
    setSchoolItemsCount((prev) => prev + addedSchool);
    setWrongItemsCount((prev) => prev + addedWrong);
    setHeldItems([]);

    if (addedSchool > 0 && addedWrong === 0) {
      playSound('victory');
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
      });
      showToast(`🎉 Sukses mengumpulkan ${addedSchool} barang sekolah! (+${deltaScore} Poin)`, false);
    } else if (addedWrong > 0) {
      playSound('wrong');
      showToast(`⚠️ Termasuk ${addedWrong} barang BUKAN sekolah! Nilai dikurangi. (${deltaScore >= 0 ? `+${deltaScore}` : deltaScore} Poin)`, true);
    }
  };

  // Auto deposit if entering zone with items
  useEffect(() => {
    if (gameStage !== 'playing' || heldItems.length === 0) return;

    const checkInterval = setInterval(() => {
      if (isInsideCollectionZone() && heldItems.length > 0) {
        handleDepositItems();
      }
    }, 500);

    return () => clearInterval(checkInterval);
  }, [gameStage, heldItems]);

  // Virtual Joystick Touch Handlers
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    const touch = e.touches[0];
    const rect = e.currentTarget.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = (touch.clientX - centerX) / (rect.width / 2);
    const dy = (touch.clientY - centerY) / (rect.height / 2);

    joystickRef.current = {
      x: Math.max(-1, Math.min(1, dx)),
      y: Math.max(-1, Math.min(1, dy)),
      active: true,
    };
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!joystickRef.current.active) return;
    const touch = e.touches[0];
    const rect = e.currentTarget.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = (touch.clientX - centerX) / (rect.width / 2);
    const dy = (touch.clientY - centerY) / (rect.height / 2);

    joystickRef.current.x = Math.max(-1, Math.min(1, dx));
    joystickRef.current.y = Math.max(-1, Math.min(1, dy));
  };

  const handleTouchEnd = () => {
    joystickRef.current = { x: 0, y: 0, active: false };
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col justify-between select-none overflow-hidden text-white font-sans">
      {/* 1. TOP STATUS BAR / HEADER */}
      <div className="relative z-30 px-3 py-2.5 bg-slate-900/80 backdrop-blur-md border-b border-white/10 flex items-center justify-between">
        {/* Left: Title & Selected Character */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-lg shadow-sm">
            🎒
          </div>
          <div>
            <h1 className="font-fredoka font-bold text-sm sm:text-base leading-tight text-white flex items-center gap-1.5">
              <span>Kumpulkan Barang Sekolah</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-sans px-1.5 py-0.5 rounded border border-emerald-500/30">
                3D Open World
              </span>
            </h1>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Cari perlengkapan kelas & kumpulkan di Zona Lingkaran Emas Meja Guru!
            </p>
          </div>
        </div>

        {/* Right: Controls & Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {gameStage === 'playing' && (
            <>
              {/* Score Indicator */}
              <div className="bg-amber-500/20 border border-amber-400/40 px-3 py-1 rounded-xl flex items-center gap-1.5">
                <Trophy className="w-4 h-4 text-yellow-300" />
                <span className="font-fredoka font-bold text-base text-yellow-300">
                  {score}
                </span>
                <span className="text-[10px] text-yellow-100 hidden xs:inline">Poin</span>
              </div>

              {/* Timer 60s */}
              <div
                className={`px-3 py-1 rounded-xl border flex items-center gap-1.5 transition-colors ${
                  timeLeft <= 10
                    ? 'bg-rose-500/30 border-rose-400 text-rose-300 animate-pulse'
                    : 'bg-sky-500/20 border-sky-400/40 text-sky-200'
                }`}
              >
                <Clock className="w-4 h-4" />
                <span className="font-fredoka font-bold text-base">
                  {timeLeft}s
                </span>
              </div>
            </>
          )}

          {/* Fullscreen Button */}
          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors"
            title={isFullscreen ? 'Keluar Layar Penuh' : 'Layar Penuh'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Close Game Button */}
          <button
            onClick={() => {
              playSound('click');
              onClose();
            }}
            className="p-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/40 text-rose-200 border border-rose-400/30 transition-colors"
            title="Tutup Game"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. MAIN VIEW AREA */}
      <div className="relative flex-1 w-full h-full overflow-hidden">
        {/* CHARACTER SELECTION STAGE */}
        {gameStage === 'character_select' && (
          <div className="absolute inset-0 z-40 bg-gradient-to-b from-slate-900 via-sky-950 to-slate-900 flex flex-col items-center justify-center p-4 overflow-y-auto">
            <div className="max-w-md w-full bg-slate-800/90 backdrop-blur-xl border border-white/15 rounded-3xl p-5 shadow-2xl flex flex-col gap-4 text-center my-auto animate-in zoom-in-95">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400 bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/20">
                  Pilih Karakter Terlebih Dahulu
                </span>
                <h2 className="font-fredoka font-bold text-2xl text-white mt-2">
                  Petualangan 3D Sekolah 🏫
                </h2>
                <p className="text-xs text-slate-300 mt-1">
                  Pilih karakter favoritmu untuk menjelajahi halaman sekolah dan mengumpulkan barang-barang edukasi!
                </p>
              </div>

              {/* Characters Grid */}
              <div className="grid grid-cols-2 gap-2.5 text-left">
                {CHARACTERS_3D.map((char) => {
                  const isSelected = selectedChar === char.id;
                  return (
                    <button
                      key={char.id}
                      onClick={() => {
                        setSelectedChar(char.id);
                        playSound('pop');
                      }}
                      className={`p-3 rounded-2xl border-2 transition-all flex flex-col gap-1.5 text-left active:scale-95 ${
                        isSelected
                          ? 'bg-amber-500/20 border-amber-400 shadow-md shadow-amber-500/20'
                          : 'bg-white/5 border-white/10 hover:bg-white/10 opacity-80'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-3xl">{char.emoji}</span>
                        {isSelected && <CheckCircle2 className="w-5 h-5 text-amber-400" />}
                      </div>
                      <div>
                        <div className="font-fredoka font-bold text-sm text-white">{char.name}</div>
                        <div className="text-[11px] text-amber-300 font-medium">{char.role}</div>
                      </div>
                      <p className="text-[10px] text-slate-300 leading-snug line-clamp-2">
                        {char.description}
                      </p>
                    </button>
                  );
                })}
              </div>

              {/* Game Rules Info Card */}
              <div className="bg-slate-900/60 border border-slate-700 rounded-2xl p-3 text-left flex flex-col gap-1.5 text-[11px] text-slate-300">
                <div className="font-bold text-amber-300 flex items-center gap-1.5">
                  <Compass className="w-4 h-4" />
                  <span>Aturan Game 60 Detik:</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-emerald-400 font-bold">✅ Barang Sekolah:</span>
                  <span>Buku, pensil, tas, penggaris (+10 Poin)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-rose-400 font-bold">❌ BUKAN Sekolah:</span>
                  <span>Stik PS, burger kotor, sampah (-5 Poin)</span>
                </div>
                <div className="text-[10px] text-slate-400 italic">
                  💡 Bawa barang yang diambil dan kumpulkan kembali ke lingkaran emas sebelum waktu 60 detik habis!
                </div>
              </div>

              {/* Start Button */}
              <button
                onClick={handleStartGame}
                className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white font-fredoka font-bold text-base rounded-2xl shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-2 active:scale-95 transition-all border border-emerald-300"
              >
                <span>Masuk ke Dunia 3D</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* 3D PLAYING CANVAS */}
        <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

        {/* IN-GAME HUD OVERLAYS */}
        {gameStage === 'playing' && (
          <>
            {/* Backpack / Held Items Bar */}
            <div className="absolute top-3 left-3 z-20 flex flex-col gap-1.5">
              <div className="bg-slate-900/80 backdrop-blur-md border border-white/20 rounded-2xl p-2.5 flex items-center gap-2 shadow-lg">
                <div className="flex items-center gap-1.5">
                  <Backpack className="w-4 h-4 text-sky-400" />
                  <span className="text-xs font-bold text-slate-200">
                    Tas Bawaan ({heldItems.length}):
                  </span>
                </div>

                <div className="flex items-center gap-1 min-w-[70px]">
                  {heldItems.length === 0 ? (
                    <span className="text-[10px] text-slate-400 italic">Kosong</span>
                  ) : (
                    heldItems.map((item, idx) => (
                      <span
                        key={idx}
                        className={`text-base p-1 rounded-lg border ${
                          item.isSchoolItem ? 'bg-emerald-500/20 border-emerald-400' : 'bg-rose-500/20 border-rose-400 animate-pulse'
                        }`}
                        title={item.name}
                      >
                        {item.emoji}
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Quick instruction chip */}
              <div className="bg-amber-500/20 backdrop-blur-xs border border-amber-400/40 rounded-xl px-2.5 py-1 text-[10px] text-amber-200 max-w-[220px]">
                🚩 Setor di Lingkaran Emas Meja Guru!
              </div>
            </div>

            {/* Floating Toast Notification */}
            {toastMessage && (
              <div
                className={`absolute top-16 left-1/2 -translate-x-1/2 z-30 px-4 py-2 rounded-2xl border font-bold text-xs shadow-xl backdrop-blur-md animate-in slide-in-from-top duration-200 flex items-center gap-2 max-w-[90%] text-center ${
                  toastMessage.isError
                    ? 'bg-rose-600/90 text-white border-rose-300'
                    : 'bg-emerald-600/90 text-white border-emerald-300'
                }`}
              >
                {toastMessage.isError ? (
                  <AlertTriangle className="w-4 h-4 text-yellow-300 flex-shrink-0" />
                ) : (
                  <Sparkles className="w-4 h-4 text-yellow-300 flex-shrink-0" />
                )}
                <span>{toastMessage.text}</span>
              </div>
            )}

            {/* ON-SCREEN VIRTUAL JOYSTICK (Mobile / Touch Drag) */}
            <div className="absolute bottom-6 left-6 z-20 flex flex-col items-center gap-1">
              <div
                onTouchStart={handleTouchStart}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
                className="w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-slate-900/60 backdrop-blur-md border-2 border-white/30 flex items-center justify-center relative touch-none shadow-xl active:border-emerald-400"
              >
                {/* Center crosshair */}
                <div className="w-1.5 h-1.5 rounded-full bg-white/40" />

                {/* Movable Thumb Knob */}
                <div
                  className="w-12 h-12 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 border-2 border-white shadow-md flex items-center justify-center text-xs text-white absolute pointer-events-none transition-transform duration-75"
                  style={{
                    transform: `translate(${joystickRef.current.x * 35}px, ${joystickRef.current.y * 35}px)`,
                  }}
                >
                  🕹️
                </div>
              </div>
              <span className="text-[10px] text-slate-300 font-bold bg-slate-900/70 px-2 py-0.5 rounded-md border border-white/10">
                Arah Jalan
              </span>
            </div>

            {/* ACTION BUTTONS (AMBIL & SPRINT) */}
            <div className="absolute bottom-6 right-6 z-20 flex items-end gap-3">
              {/* Sprint Button */}
              <button
                onTouchStart={() => setSprintActive(true)}
                onTouchEnd={() => setSprintActive(false)}
                onMouseDown={() => setSprintActive(true)}
                onMouseUp={() => setSprintActive(false)}
                className={`w-14 h-14 rounded-2xl border flex flex-col items-center justify-center gap-0.5 shadow-lg active:scale-90 transition-all ${
                  sprintActive
                    ? 'bg-amber-500 border-amber-300 text-white scale-105 shadow-amber-500/50'
                    : 'bg-slate-900/70 backdrop-blur-md border-white/20 text-amber-300'
                }`}
                title="Lari Cepat (Shift)"
              >
                <Zap className="w-5 h-5" />
                <span className="text-[9px] font-bold">LARI</span>
              </button>

              {/* Pickup / Deposit Action Button */}
              <button
                onClick={() => {
                  if (heldItems.length > 0 && isInsideCollectionZone()) {
                    handleDepositItems();
                  } else {
                    attemptPickup();
                  }
                }}
                className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 border-3 border-emerald-200 text-white flex flex-col items-center justify-center gap-1 shadow-xl shadow-emerald-500/40 active:scale-90 transition-transform"
                title="Ambil / Setor Barang (Spasi)"
              >
                <PackageCheck className="w-7 h-7" />
                <span className="text-xs font-fredoka font-bold leading-tight">
                  {heldItems.length > 0 && isInsideCollectionZone() ? 'SETOR' : 'AMBIL'}
                </span>
              </button>
            </div>
          </>
        )}

        {/* 3. GAME OVER MODAL (Waktu 60 Detik Habis) */}
        {gameStage === 'gameover' && (
          <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center p-4 animate-in zoom-in-95">
            <div className="max-w-md w-full bg-slate-900 border-2 border-emerald-400/50 rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center gap-4">
              <div className="w-20 h-20 rounded-3xl bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-4xl shadow-inner animate-bounce">
                🏆
              </div>

              <div>
                <span className="text-xs font-bold text-amber-300 uppercase tracking-widest bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/20">
                  Waktu 60 Detik Selesai!
                </span>
                <h3 className="font-fredoka font-bold text-2xl sm:text-3xl text-white mt-2">
                  Hasil Akhir Pengumpulan
                </h3>
              </div>

              {/* Score Recap Card */}
              <div className="w-full bg-slate-800/80 rounded-2xl p-4 border border-white/10 flex flex-col gap-2.5">
                <div className="flex items-center justify-between text-sm border-b border-white/10 pb-2">
                  <span className="text-slate-300">Total Skor Diperoleh:</span>
                  <strong className="font-fredoka text-2xl text-yellow-300">
                    {score} Poin
                  </strong>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 text-emerald-300 font-semibold">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Barang Sekolah Terkumpul:</span>
                  </span>
                  <strong className="text-emerald-400 font-fredoka text-base">
                    +{schoolItemsCount} Barang
                  </strong>
                </div>

                {wrongItemsCount > 0 && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1.5 text-rose-300 font-semibold">
                      <AlertTriangle className="w-4 h-4 text-rose-400" />
                      <span>Barang Bukan Sekolah:</span>
                    </span>
                    <strong className="text-rose-400 font-fredoka text-base">
                      -{wrongItemsCount} Barang
                    </strong>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-3 w-full">
                <button
                  onClick={handleStartGame}
                  className="flex-1 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 text-white font-fredoka font-bold text-sm rounded-xl shadow-md active:scale-95 flex items-center justify-center gap-1.5 border border-emerald-300"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Main Lagi</span>
                </button>

                <button
                  onClick={() => {
                    playSound('click');
                    onClose();
                  }}
                  className="flex-1 py-3 bg-white/10 hover:bg-white/20 text-white font-fredoka font-bold text-sm rounded-xl border border-white/20 active:scale-95"
                >
                  <span>Selesai & Keluar</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
