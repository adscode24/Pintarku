# Anak Pintar - Native Android APK Project
===================================================

Aplikasi edukasi interaktif anak usia 6-10 tahun:
- Menulis Huruf & Kata
- Membaca Bersuara Perempuan
- Matematika Dasar Berhitung
- 200 Level Kuis Interaktif
- Istirahat Game Apel Berkarakter

## CARA 1: COMPILE APK DENGAN GITHUB CLOUD (OTOMATIS & CEPAT)
Proyek ini sudah dilengkapi dengan konfigurasi GitHub Actions Cloud CI (.github/workflows/build-apk.yml).
Tidak perlu menginstall Android Studio atau Java di komputer Anda!

Langkah-langkah:
1. Buat repository baru di GitHub (misal: 'anak-pintar-app').
2. Upload / push seluruh berkas proyek ini ke repository GitHub Anda:
   git remote add origin https://github.com/USERNAME/anak-pintar-app.git
   git branch -M main
   git push -u origin main
3. Buka tab **Actions** di repository GitHub Anda.
4. Workflow **"Build Native Android APK (GitHub Cloud)"** akan otomatis berjalan.
5. Setelah selesai (berwarna hijau centang), klik hasil workflow dan unduh file APK dari bagian **Artifacts**:
   - `AnakPintar-release.apk`
   - `AnakPintar-debug.apk`
6. File APK tersebut adalah Native APK resmi yang siap dipasang langsung di HP atau Tablet Android.

## CARA 2: COMPILE LOKAL DENGAN ANDROID STUDIO
1. Pastikan Anda telah menginstal Android Studio & Android SDK (API 34/35).
2. Buka Android Studio -> Pilih "Open an Existing Project".
3. Pilih folder 'android' dari folder proyek ini.
4. Biarkan Gradle melakukan sync.
5. Buat APK rilis via menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. File APK akan berada di: android/app/build/outputs/apk/release/app-release.apk
