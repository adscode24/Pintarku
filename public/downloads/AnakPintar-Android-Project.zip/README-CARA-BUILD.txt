# Anak Pintar - Proyek Android Studio (Capacitor)
===================================================

Aplikasi edukasi interaktif anak usia 6-10 tahun:
- Menulis Huruf & Kata
- Membaca Bersuara Perempuan
- Matematika Dasar Berhitung
- 200 Level Kuis Interaktif
- Istirahat Game Apel Berkarakter

## Cara Membuka & Build di Android Studio:
1. Pastikan Anda telah menginstal Android Studio & Android SDK (API 34/35).
2. Buka Android Studio -> Pilih "Open an Existing Project".
3. Pilih folder 'android' dari folder proyek ini.
4. Biarkan Gradle melakukan sync.
5. Jalankan ke HP fisik atau Emulator melalui tombol "Run" (Shift + F10),
   atau buat APK rilis via menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
